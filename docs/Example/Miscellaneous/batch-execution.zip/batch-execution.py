import os
import shutil

placeholder = '$groundMotionRecord'

template_file = open("batch-execution.supan", "r")
template_model = template_file.read()

records = os.listdir('NZStrongMotion')

for record in records:
    try:
        # try to create folder
        os.mkdir(record)
    except OSError:
        # if folder exists, remove it and create an empty one
        shutil.rmtree(record)
        os.mkdir(record)
    # switch to the created folder
    os.chdir(record)
    # create the model file by using the record name
    model_file = open(record + ".sp", "w")
    # write modified script to the model file
    # remember now we are in the newly created folder, the record is stored in ..\NZStrongMotion
    model_file.write(template_model.replace(placeholder, '..\\NZStrongMotion\\' + record))
    # remember to close before running the model
    model_file.close()
    # now invoke suanPan to run the model
    os.system('suanPan -f ' + record + '.sp > log.txt')
    # need to change back to parent folder
    os.chdir('..')
